import { TbPointFilled } from "react-icons/tb";
import { IoReload } from "react-icons/io5";
// import { HiMiniArrowTopRightOnSquare } from "react-icons/hi2";
// import { useState } from "react";
import { CiCircleCheck, CiCircleRemove, } from "react-icons/ci";
import { FiDatabase } from "react-icons/fi";


let CurrDateTime = () => {
  let dt = Date();
  return dt.slice(0,25);
};

const Main = () => {
  return (
    <div className="bg-white">
      <header className="mt-5 py-3 grid header1">
        <div>
          <h2 className="font-bold text-2xl">
            Welcome to Monitoring Dashboard
          </h2>
          <p className="text-gray-700">
            Monitor the health and status of e-commerce microservices
          </p>
        </div>
        <div className="h-10">
          <p className="h-full grid items-center para1">
            <span className="h-full w-10"><TbPointFilled className="text-green-500 h-full w-full" /></span>
            <span className="">
              <CurrDateTime />
            </span>
            <button className="border p-4" onClick={CurrDateTime}>
              <IoReload />
            </button>
            
          </p>
        </div>
      </header>
      <main>
        <div className="mainbox1 grid h-1/5">
          <div>
            <div><CiCircleCheck className="bg-green-800"/></div>
            <div>
              <h2></h2>
              <p>Services Up</p>
            </div>
          </div>
          <div>
            <div><CiCircleRemove className="bg-green-800"/></div>
            <div>
              <h2></h2>
              <p>Services Down</p>
            </div>
          </div>
          <div>
            <div><FiDatabase className="bg-green-800"/></div>
            <div>
              <h2></h2>
              <p>Total Services</p>
            </div>
          </div>
        </div>
        <div className="mainbox2"> From API
          <div>
            <div></div>
            <div></div>
          </div>
          <div>
            //here logic of active and All Type of API
          </div>
        </div>
        <div className="mainbox3">//logic dependent from API
          <div></div>
          <div></div>
        </div>
      </main>
    </div>
  );
};

export default Main;
