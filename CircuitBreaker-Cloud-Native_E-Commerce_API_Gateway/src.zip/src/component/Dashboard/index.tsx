import Main from "./main";
import Navbar from "./navBar";

const Dashboard = () => {
  return (
    <div className="maincon grid w-screen h-screen">
      <div>
        <Navbar />
      </div>
      <div>
        <Main />
      </div>
    </div>
  );
};
export default Dashboard;
