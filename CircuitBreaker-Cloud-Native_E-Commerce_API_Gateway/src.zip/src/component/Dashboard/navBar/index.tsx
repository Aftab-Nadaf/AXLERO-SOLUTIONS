import { FaCartShopping } from "react-icons/fa6";
import { MdHome } from "react-icons/md";
import { IoCubeOutline } from "react-icons/io5";
import { HiOutlineDocumentText } from "react-icons/hi2";
import { CiCircleInfo } from "react-icons/ci";
const Navbar = () => {
  return (
    <div className="bg-slate-900 w-full h-full ">
      <header>
        <div className="grid con1 w-full h-1/10">
          <div className="h-10 mt-5 titleicon">
            <FaCartShopping className="text-blue-500 h-full w-full" />
          </div>
          <div className="grid con2 text-blue-500 w-full mt-5 h-full ">
            <h2 className="">E-Commerce Dashboard</h2>
            <p className="-mt-5">Monitor API</p>
          </div>
        </div>
        <div className="navlist h-3/10">
          <ul className="h-full">
            <li className="lis h-12"><span className="iconbar"><MdHome className="h-full w-full" /></span><span className="m">Dashboard</span></li>
            <li className="lis h-12"><span className="iconbar"><IoCubeOutline className="h-full w-full"/></span>Services</li>
            <li className="lis h-12"><span className="iconbar"><HiOutlineDocumentText className="h-full w-full"/></span>API Logs</li>
            <li className="lis h-12"><span className="iconbar"><CiCircleInfo className="h-full w-full"/></span>About</li>
          </ul>
        </div>
      </header>
      <footer className="absolute bottom-10">
        <p>CircuitBreaker Project v0.1.0</p>
      </footer>
    </div>
  );
};

export default Navbar;
